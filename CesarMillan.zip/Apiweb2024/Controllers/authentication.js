import{loginauth}from"../Controllers/firebase.js"

const recibir = document.getElementById("boton_n")

async function validar(){

    const email = document.getElementById('email').value
    const password=document.getElementById('password').value

    const verificar=loginauth(email,password)
    const validation= await verificar

    if(verificar != null){
        alert("Usuario autenticado: " + email)
        window.location.href = "../Templates/home.html"
    }else{
        console.log("Sesion "+ email + " not validation")
        alert("Error de usuario verifique usuario y/o contraseña")
    }

}

window.addEventListener('DOMContentLoaded', async() =>{
    recibir.addEventListener('click', validar)

})